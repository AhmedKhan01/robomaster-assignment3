SCE 672 ASSIGNMENT 3 — REPRODUCIBLE SUBMISSION
Mohammad Ahmed Khan, 9 November 2026

READ FIRST
The experiment is complete. Offline analysis below never imports ROS or sends
robot commands. Do not repeat completed evaluation slots or change the frozen
settings to improve their score. Keep this archive/repository private.

DELIVERABLES
report/assignment3_report.pdf       LaTeX report, equations, all trial tables
report/assignment3_report.tex       Editable LaTeX source
analysis/results/figure_A...D...    Four required figures, PDF and PNG, plus all-trial scatter plots
analysis/results/metrics.json      Complete statistics in SI units (metres)
analysis/results/evaluation_trial_table.csv
analysis/results/eval_*_filter_states.csv   State and full covariance histories
analysis/results/stop_events.csv   Extracted transitions and stop reasons
analysis/results/audit.json        Frozen-file checks and original log hashes
presentation/presentation_link.txt Editable presentation link and export guidance
presentation/speaker_script.txt    4–5 minute rehearsal script

DATA AND SOURCE ORGANIZATION
evaluation/                       Original uploaded evaluation package and logs
  feedback_runs/                  Ten evaluations and frozen preview
  frozen_robot_sources/           Frozen ROS2 package and tag observer
  freeze_manifest.json            Original freeze manifest (unchanged)
  feedback_core.py, feedback_runner.py, ekf_core.py, protocol.json, ekf_config.json
calibration/runs/                 Five original pilot CSV/metadata pairs
calibration/physical_measurements.json  Student-confirmed physical endpoints
calibration/verified_results/     Original calibration tables and figures
ekf_development/                  Original offline replay and no-motion preview code
pilot/                            Characterization controller and tests
commissioning/                   Two commissioning runs, excluded from evaluation
diagnostics/                     Available slow03/slow04 abort logs (not scored)
input_sha256.json                Hashes of all packaged raw logs and metadata

The evaluation upload contains ten executed evaluation attempts, zero evaluation
aborts and one preview. Earlier development aborts are separate. The supplied
legacy diagnostics are not an exhaustive archive of every earlier terminal test.
Do not infer missing physical endpoint measurements from ToF.

QUICK OFFLINE REPRODUCTION
From this extracted assignment3_submission directory, with Python 3.12, NumPy
and Matplotlib installed (see requirements_analysis.txt):

  python3 analysis/analyze_evaluation.py

This verifies 48 packaged frozen hashes plus every run's manifest/config/source
identity, regenerates trial tables, filter-state/stop CSVs, statistics and figures.
It intentionally does NOT call the hardware/environment freeze verifier using
this computer's paths. The original verifier requires the original WSL paths.

To recompute calibration independently into a NEW output directory:

  python3 calibration/calibrate.py --root calibration --output calibration_recheck
  python3 calibration/plot_calibration.py calibration_recheck

To repeat the calibration-only EKF replay (output directory must be new):

  python3 ekf_development/replay_ekf.py --calibration-dir calibration --output replay_recheck

To run the supplied ROS-free tests:

  (cd evaluation && python3 -m unittest -v test_feedback.py test_freeze.py)
  (cd ekf_development && python3 -m unittest -v test_ekf.py)
  (cd calibration && python3 -m unittest -v test_calibration.py)

Additional statistics: analysis/trial_statistics.py regenerates the overlaid
scatter plots, physical endpoint scatter, variance tables, endpoint-error
covariance matrices and the generated LaTeX analysis section. Each sample
variance/covariance uses one endpoint per trial and denominator n-1, separately
for U and F (n=5 each). Outputs are in analysis/results/trial_statistics.json,
sample_variance_by_method.csv and *_endpoint_error_covariance_mm2.csv.
These describe empirical endpoint spread, not the EKF internal P or sensor R.

To rebuild the LaTeX report (requires pdfLaTeX, Latin Modern, standard packages):

  python3 report/build_report.py
  (cd report && pdflatex -interaction=nonstopmode -halt-on-error assignment3_report.tex)
  (cd report && pdflatex -interaction=nonstopmode -halt-on-error assignment3_report.tex)

To export the same report to editable Word (requires pandoc and python-docx):

  python3 report/export_word.py

The edited prose is maintained in report/report_template.tex. build_report.py
first audits/recomputes all results, then fills its statistics section.

ENDPOINT AND RESIDUAL POLICIES
Evaluation endpoint estimates: median last ten FEEDBACK_STATE values at least
one second after STOP. Ground truth D = measured start gap - measured final gap.
Samples in this endpoint window are correlated. Physical measurement division
is 1 mm, not a guaranteed uncertainty bound. All scores retain all ten runs.
Same-trajectory estimator comparisons use only the five filtered runs.

Figure B uses within-support interpolation over the common active time interval
for each method, n=5 throughout. There is no extrapolation beyond a run's stop.
Figure D assigns each range sample its callback-receipt source time (receipt
elapsed minus reported source age), then interpolates odometry pose and logged
EKF state at that same time. Maximum brackets are 0.20/0.10 s, respectively, with
no extrapolation and range age <=0.40 s. Each progress point uses its first
raw-odometry crossing. Hardware acquisition synchronization remains unavailable. ToF is a filter input, not ground truth.

RESULTS AND LIMITATIONS
All ten stop at RAW_TOF_GUARD. Final gaps are 0.245–0.270 m versus the 0.200 m
physical goal. The mean gaps are 0.2550 m (U) and 0.2606 m (F). The five filtered
runs give endpoint RMSE 4.38 mm raw, 6.28 mm corrected, 5.92 mm EKF. The EKF's
0.36 mm numerical gain over corrected odometry is below the ruler division and
does not establish a meaningful advantage; raw odometry performs better here.
The original conservative guard remains unchanged. Calibration transfer,
correlation, assumed dynamics/noise and upright-tag pixel steering are disclosed.

ROBOT RUNTIME RECORD (NOT NEEDED FOR OFFLINE ANALYSIS)
ROS2 Jazzy. Driver/SDK environment: Python 3.12.3, NumPy 1.26.4,
robomaster 0.1.2.0, opencv-python 4.11.0.86, as recorded in the freeze manifest.
Tag observer: isolated OpenCV contrib headless 5.0.0.93 and NumPy 2.5.4 via
~/rm_tag_cv5_test on PYTHONPATH. Do not install that NumPy over the base SDK
environment: its SciPy 1.11.4 requires NumPy <1.28.

The frozen driver is the only SDK owner. Arm startup target (105,35) mm.
Topic /rm/cmd_vel uses geometry_msgs/Twist. /rm/odom is nav_msgs/Odometry.
/rm/range is Float64MultiArray [raw range metres, source age seconds].
/rm/tag_observation is String JSON, pixel error rather than angular bearing.
Keep the legacy planner stopped during feedback operation; it can publish
competing motion commands. Never reposition manually while the driver is active.
The frozen source snapshot contains old backups and Zone.Identifier sidecars
because they were part of the original hash manifest; do not alter this evidence.

Hardware source for a fresh workspace, if ever needed, is
evaluation/frozen_robot_sources/rm_flatness_nav (colcon ROS2 package). The tested
launch explicitly used ~/venvs/rm_flatness/bin/python on the installed driver
entry point. Running a rebuilt launcher with system Python may miss the SDK.
The original driver may move the arm at startup. Offline reproduction needs
neither the driver nor the observer running. A new physical experiment requires
a separately reviewed measured setup and fresh run identifiers.

SOFTWARE AND ASSISTANCE
Reuses the earlier ROS2 project, DJI SDK, ROS2, OpenCV, NumPy and Matplotlib.
ChatGPT/Codex assisted implementation, debugging, analysis and document drafting.
The student supplied the real robot trials and physical endpoint measurements.
No synthetic measurements enter the evaluation. Review the report and rehearse
the presentation. Check course-portal deadline, video and naming requirements.
