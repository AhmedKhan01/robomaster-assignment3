# Upload guide (Windows + WSL)

The supplied handout explicitly requests a private repository. If the professor has now requested public sharing, use the public command below; otherwise use private. This guide does not publish anything automatically.

1. Download `assignment3_github_upload.zip` into `C:\Users\khanm\Downloads`. Leave it zipped in Windows.
2. Connect the laptop to an internet connection. Stop robot programs before leaving the robot network. Open a fresh WSL terminal.
3. Extract under the Linux home directory (do not use Windows Extract All):

```bash
mkdir -p ~/github_projects
python3 -m zipfile -e /mnt/c/Users/khanm/Downloads/assignment3_github_upload.zip ~/github_projects
cd ~/github_projects/robomaster-assignment3
```

If that directory already contains your own work, choose a new extraction parent instead of overwriting it. Keep the filename exactly as downloaded, or adjust the command to its actual name.

4. Install Git and GitHub CLI if needed:

```bash
sudo apt update
sudo apt install -y git gh
```

5. Sign in:

```bash
gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git
```

Follow the terminal's browser/device-code instructions. If WSL does not open a browser, open the displayed URL in Windows Chrome and enter the displayed code yourself. Authenticate with your intended GitHub account. Do not paste a token or password into code, this repository, or a chat.

6. Prepare the local commit:

```bash
git init -b main
git config user.name "Mohammad Ahmed Khan"
git config user.email "YOUR_GITHUB_NOREPLY_EMAIL"
git add .
git status --short
git commit -m "Add Assignment 3 code, experimental logs and analysis"
```

Replace `YOUR_GITHUB_NOREPLY_EMAIL` with your exact private commit email from GitHub Settings > Emails before running that line. The user.name and user.email settings apply to this repository only. Review the staged list before committing. The ZIP includes hidden `.gitignore` and `.gitattributes`; `git add .` includes them. Do not add your virtual environment or credentials.

7. Run exactly one of these creation commands. Do not create an empty repository in the browser first.

Private, as specified in the supplied handout:

```bash
gh repo create robomaster-assignment3 --private --source=. --remote=origin --push
```

Public, if the instructor has superseded the private-repository instruction:

```bash
gh repo create robomaster-assignment3 --public --source=. --remote=origin --push
```

The repository is created under the signed-in account. This is a new repository, separate from your previous flatness-navigation project. If the name is already used, select a different new name; do not force-push over an existing repository.

8. Confirm the upload and view the repository:

```bash
gh repo view --json url,visibility
git status --short
gh repo view --web
```

An empty `git status --short` means the local checkout has no uncommitted changes. Verify GitHub shows the code folders, raw CSV files, README and report. Submit the resulting repository URL. For a private repository, use GitHub Settings > Collaborators to invite the professor's verified GitHub username as required.

Do not upload just the ZIP file as the only repository item: these commands publish its extracted contents so the code is browseable. Keep the frozen snapshot unchanged. A Windows-native clone may reject colon-containing evidence filenames; clone under WSL if needed.
