"""Regenerate the audited analysis, figures and report source. No robot connection."""
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
for script in ['analyze_evaluation.py','trial_statistics.py']:
    subprocess.run([sys.executable,str(ROOT/'analysis'/script)],check=True,stdout=subprocess.DEVNULL)
text=(ROOT/'report/report_template.tex').read_text()
assert text.count('@@TRIAL_STATISTICS@@')==1
text=text.replace('@@TRIAL_STATISTICS@@',(ROOT/'analysis/results/trial_statistics_section.tex').read_text())
(ROOT/'report/assignment3_report.tex').write_text(text)
print('Updated report source and all trial statistics.')
