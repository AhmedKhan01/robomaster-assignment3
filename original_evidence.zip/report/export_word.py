from pathlib import Path
import re,subprocess,os,zipfile
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
root=Path(__file__).resolve().parents[1]
src=root/'report/assignment3_report.tex'
s=src.read_text().replace('m$^2$',r'$\mathrm{m}^2$')
s=re.sub(r'\\rm\s+([A-Za-z]+)',r'\\mathrm{\1}',s)
s=s.replace('\\begin{abstract}','\\section*{Abstract}').replace('\\end{abstract}','')
start=s.index('\\begin{center}',s.index('\\begin{document}'));end=s.index('\\end{center}',start)+len('\\end{center}')
s=s[:start]+'''State Estimation and Feedback Approach

RoboMaster EP: calibrated odometry and a five-state EKF

Mohammad Ahmed Khan

SCE 672: Advanced Robotics --- Term Project Assessment 3

King Fahd University of Petroleum \& Minerals

Instructor: Prof. Aamer Iqbal Bhatti

9 November 2026
'''+s[end:]
s='\n'.join(line for line in s.splitlines() if not line.startswith('\\newcommand{\\fig}'))
def arg_at(t,i):
 while t[i].isspace():i+=1
 assert t[i]=='{'
 start=i+1;depth=1;i+=1
 while depth:
  if t[i]=='{' and t[i-1]!='\\':depth+=1
  if t[i]=='}' and t[i-1]!='\\':depth-=1
  i+=1
 return t[start:i-1],i
while '\\fig{' in s:
 start=s.index('\\fig{');i=start+4;name,i=arg_at(s,i);width,i=arg_at(s,i);caption,i=arg_at(s,i)
 path=root/'analysis/results'/f'{name}.png'
 repl='\\begin{figure}\n\\centering\n\\includegraphics[width='+width+'\\linewidth]{'+str(path)+'}\n\\caption{'+caption+'}\n\\end{figure}'
 s=s[:start]+repl+s[i:]
s=s.replace('../calibration/verified_results/sensor_travel.png',str(root/'calibration/verified_results/sensor_travel.png'))
s=s.replace('\\begin{samepage}','').replace('\\end{samepage}','').replace('\\allowbreak ','').replace('\\clearpage','')
work=root/'tmp_word_conversion';work.mkdir(exist_ok=True)
clean=work/'conversion.tex';clean.write_text(s)
subprocess.run(['pandoc',str(clean),'-f','latex','-t','docx','--number-sections','-o',str(work/'draft.docx')],check=True)
d=Document(work/'draft.docx')
S={st.name:st for st in d.styles}
sec=d.sections[0];sec.page_width=Inches(8.2677);sec.page_height=Inches(11.6929)
sec.top_margin=sec.bottom_margin=Inches(.80);sec.left_margin=sec.right_margin=Inches(.82)
sec.header_distance=sec.footer_distance=Inches(.35)
for name in ['Normal','Body Text','First Paragraph','Abstract','Compact']:
 if name not in d.styles:continue
 st=S[name];st.font.name='Times New Roman';st.font.size=Pt(11);st.font.color.rgb=RGBColor(0,0,0)
 st.paragraph_format.line_spacing=1.08;st.paragraph_format.space_after=Pt(6)
for name,size in [('Title',20),('Subtitle',13),('Heading 1',15),('Heading 2',12),('Heading 3',11),('Caption',10),('Table Caption',10),('Image Caption',10)]:
 st=S[name];st.font.name='Times New Roman';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
 st.font.bold=name.startswith('Heading')
 st.paragraph_format.space_before=Pt(12 if name.startswith('Heading') else 3);st.paragraph_format.space_after=Pt(6)
 if name.startswith('Heading'):st.paragraph_format.keep_with_next=True
 st.element.get_or_add_rPr().rFonts.set(qn('w:ascii'),'Times New Roman')
 st.element.get_or_add_rPr().rFonts.set(qn('w:hAnsi'),'Times New Roman')
for i,p in enumerate(d.paragraphs):
 if i==0:p.style=S['Title'];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 if i==1:p.style=S['Subtitle'];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 if i<7 and not p.style.name.startswith('Heading'):p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 if p.style.name.startswith('Heading') and 'Findings, limitations' in p.text:p.paragraph_format.page_break_before=False
 if p._p.xpath('.//w:drawing'):
  p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True;p.paragraph_format.space_before=Pt(8);p.paragraph_format.space_after=Pt(5)
 if p.style.name in ['Caption','Table Caption','Image Caption']:
  if p.style.name=='Table Caption':p.paragraph_format.keep_with_next=True
  p.alignment=WD_ALIGN_PARAGRAPH.LEFT;p.paragraph_format.keep_together=True;p.paragraph_format.space_after=Pt(10)
# Constrain all figure sizes while preserving aspect ratio.
for si,sh in enumerate(d.inline_shapes):
 limit=Inches(5.7 if si==4 else 6.4)
 if sh.width>limit:
  ratio=limit/sh.width;sh.height=int(sh.height*ratio);sh.width=limit
# Table widths are intentional. The complete dataset stays in each table.
widths=[[1.04,.85,.93,1.00,.95,1.05],[.73,.92,.98,1.76,1.38],[1.88,4.65],[1.06,.48,.85,.85,.85,.92,.91],[.45,1.49,.35,.59,.59,.62,.62,1.26],[1.68,1.55,1.55,1.55],[1.82,1.12,1.17,1.11,1.15],[.65,2.0,.35,1.05,1.05,1.4],[2.2,1.4,1.4,1.4],[2.2,1.4,1.4,1.4]]
for ti,t in enumerate(d.tables):
 t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 ww=widths[ti] if ti<len(widths) and len(widths[ti])==len(t.columns) else [6.5/len(t.columns)]*len(t.columns)
 scale=6.5/sum(ww);ww=[x*scale for x in ww]
 for j,col in enumerate(t.columns):col.width=Inches(ww[j])
 pr=t._tbl.tblPr;b=OxmlElement('w:tblBorders')
 for edge in ['top','left','bottom','right','insideH','insideV']:
  x=OxmlElement('w:'+edge);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');b.append(x)
 pr.append(b)
 for ri,row in enumerate(t.rows):
  cant=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(cant)
  if ri==0:
   hdr=OxmlElement('w:tblHeader');row._tr.get_or_add_trPr().append(hdr)
  for j,c in enumerate(row.cells):
   c.width=Inches(ww[j]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   tc=c._tc.get_or_add_tcPr();shd=OxmlElement('w:shd');shd.set(qn('w:fill'),'E9EDF1' if ri==0 else ('F7F8FA' if ri%2==0 else 'FFFFFF'));tc.append(shd)
   mar=OxmlElement('w:tcMar')
   for edge in ['top','left','bottom','right']:
    x=OxmlElement('w:'+edge);x.set(qn('w:w'),'70');x.set(qn('w:type'),'dxa');mar.append(x)
   tc.append(mar)
   for p in c.paragraphs:
    p.paragraph_format.keep_with_next=ri<len(t.rows)-1;p.paragraph_format.space_before=Pt(1);p.paragraph_format.space_after=Pt(2);p.paragraph_format.line_spacing=1.05
    p.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 or ti==2 else WD_ALIGN_PARAGRAPH.CENTER
    for r in p.runs:r.font.name='Times New Roman';r.font.size=Pt(9 if ti==4 else 10);r.font.color.rgb=RGBColor(0,0,0);r.bold=(ri==0)
# Restore three separate bibliography entries and its heading.
last=d.paragraphs[-1]
if last.text.startswith('9 A. I. Bhatti'):
 last.text='[3] Frozen experimental implementation and logs, 9 November 2026. See evaluation/freeze_manifest.json, feedback_core.py, ekf_core.py, frozen driver/observer sources and original run CSVs in the accompanying archive.'
 last.insert_paragraph_before('[2] Robomaster Assessment 2, supplied Phase 2 handout. Floor-tag geometry is identified as a setup difference.')
 prev=last._p.getprevious(); from docx.text.paragraph import Paragraph
 ref2=Paragraph(prev,last._parent);ref1=ref2.insert_paragraph_before('[1] A. I. Bhatti, SCE 672 Term Project Assessment 3: State Estimation and Feedback Approach, supplied proposed Phase 3 handout, KFUPM, 3 pp.')
 ref1.insert_paragraph_before('References',style=S['Heading 1'])
# Header and a dynamic page field.
h=sec.header.paragraphs[0];h.text='SCE 672 Assignment 3';h.style=S['Normal']
for r in h.runs:r.font.size=Pt(9)
f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=f.add_run();field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');r._r.addnext(field)
d.core_properties.title='State Estimation and Feedback Approach';d.core_properties.author='Mohammad Ahmed Khan'
# Normalize delimiter properties to the OOXML schema order for LibreOffice.
for dp in d.element.xpath('.//m:dPr'):
 for tag in ['begChr','sepChr','endChr','grow','shp','ctrlPr']:
  node=dp.find(qn('m:'+tag))
  if node is not None:dp.remove(node);dp.append(node)
for mf in d.settings.element.xpath('.//m:mathFont'):mf.set(qn('m:val'),'Latin Modern Math')
out=root/'report/assignment3_report.docx';d.save(out)
with zipfile.ZipFile(out) as z:
 xml=z.read('word/document.xml').decode()
 print('Native math objects:',xml.count('<m:oMath>'),'tables:',len(d.tables),'figures:',len(d.inline_shapes))
 assert xml.count('<m:oMath>')>80 and len(d.tables)==10 and len(d.inline_shapes)==7
print(out)
